#!/usr/bin/env python

import vtk

## Definition de la fenetre d'affichage
fenetre = vtk.vtkRenderWindow()
fenetre.SetSize(500,500)
fenetre.SetPosition(50,50) 
fenetre.SetWindowName("Fenetre")

## Lecture de la texture
bmp=vtk.vtkBMPReader()
#bmp.SetFileName("../DONNEES/masonry.bmp")
bmp.SetFileName("herbe.bmp")
bmp.Update()

texture=vtk.vtkTexture()
texture.SetInputConnection(bmp.GetOutputPort())
texture.InterpolateOn() #Turn on/off linear interpolation of the texture map when rendering.

plan = vtk.vtkPlaneSource()

mapperplan = vtk.vtkPolyDataMapper()
mapperplan.SetInputConnection(plan.GetOutputPort())

acteurplan = vtk.vtkActor()
acteurplan.SetMapper(mapperplan)
acteurplan.SetTexture(texture)

## Definition de la scene : 
ren = vtk.vtkRenderer()
ren.AddActor(acteurplan)
##
fenetre.AddRenderer(ren)
iren = vtk.vtkRenderWindowInteractor()
iren.SetRenderWindow(fenetre) 
iren.Initialize()
fenetre.Render()   
iren.Start() 

print '----------------------------------------------------'
