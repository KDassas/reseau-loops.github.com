#!/usr/bin/env python

import vtk
import time

print '----------------------------------------------------'

## Definition de la fenetre d'affichage
fenetre1 = vtk.vtkRenderWindow()
fenetre1.SetSize(500,500)
fenetre1.SetPosition(50,50) 
fenetre1.SetWindowName("Fenetre 1")

## Recuperation des donnees : ici un cylindre
# vtkCylinderSource creates a polygonal cylinder centered at Center;
# The axis of the cylinder is aligned along the global y-axis.
# The height and radius of the cylinder can be specified, as well as the number of sides.
cyl1 = vtk.vtkCylinderSource()
cyl1.SetRadius(1.0)             
cyl1.SetHeight(4.0)             
cyl1.SetCenter(0.0,0.0,0.0)     
cyl1.SetResolution(20)      

## Conversion des donnees en primitives graphiques 
mappercyl1 = vtk.vtkPolyDataMapper()
mappercyl1.SetInputConnection(cyl1.GetOutputPort())

## Definition des acteurs de la scene
acteurcyl1 = vtk.vtkActor()
acteurcyl1.SetMapper(mappercyl1)

## Definition de la scene : 
cam = vtk.vtkCamera()  
cam.SetViewUp(0, 1, 0)      # Set the view up direction for the camera. The default is (0,1,0).
cam.SetPosition(0, 0, -10)  # Set the position of the camera in world coordinates. The default position is (0,0,1).
cam.SetFocalPoint(0, 0, 0)  # Set the focal of the camera in world coordinates. The default focal point is the origin.
print cam

## Definition de la scene : 
ren1 = vtk.vtkRenderer()
ren1.AddActor(acteurcyl1)
ren1.SetActiveCamera(cam)  
# ren1.GetActiveCamera() permet de recuperer la camera active (valeurs par defaut)...
# ren1.ResetCamera() met a jour la camera de facon a ce que tous les acteurs soient visibles

## Silence, on tourne...
fenetre1.AddRenderer(ren1)

## Projection :
for position in range(0,11):
    print 'position=',position
    cam.SetPosition(0, 0, -position)
    fenetre1.Render()
    time.sleep(1)
time.sleep(5)
for azimuth in range(0,11):
    print 'azimuth=',azimuth
    cam.Azimuth(azimuth)
    fenetre1.Render()
    time.sleep(1)
time.sleep(5)
for roll in range(0,11):
    print 'roll=',roll
    cam.Roll(roll)
    fenetre1.Render()
    time.sleep(1)
time.sleep(5)
for yaw in range(0,6):
    print 'yaw=',yaw
    cam.Yaw(yaw)
    fenetre1.Render()
    time.sleep(1)
time.sleep(5)



    





print '----------------------------------------------------'
