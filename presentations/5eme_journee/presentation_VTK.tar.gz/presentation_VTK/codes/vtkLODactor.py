#!/usr/bin/env python

import vtk
import time

print '----------------------------------------------------'

## Definition de la fenetre d'affichage
fenetre1 = vtk.vtkRenderWindow()
fenetre1.SetSize(500,500)
fenetre1.SetPosition(50,50) 
fenetre1.SetWindowName("Fenetre 1")

## Recuperation des donnees : ici une sphere
sphere1 = vtk.vtkSphereSource()
sphere1.SetRadius(1.0)            
sphere1.SetCenter(0.0,1.0,0.0)   
sphere1.SetThetaResolution(600)  
sphere1.SetPhiResolution(600)     

colsph = vtk.vtkElevationFilter() 
colsph.SetInputConnection(sphere1.GetOutputPort())
colsph.SetLowPoint(0,1,-1)
colsph.SetHighPoint(0,1,1)


## Conversion des donnees en primitives graphiques 
mappersphere1 = vtk.vtkPolyDataMapper()
mappersphere1.SetInputConnection(colsph.GetOutputPort())

## Definition des acteurs de la scene
# LOD maxi :
#acteursphere1 = vtk.vtkActor()
# LOD intermediaire :
acteursphere1 = vtk.vtkLODActor()
print acteursphere1.GetNumberOfCloudPoints()
acteursphere1.SetNumberOfCloudPoints(1000)

acteursphere1.SetMapper(mappersphere1)

## Definition de la scene : 
ren1 = vtk.vtkRenderer()
ren1.AddActor(acteursphere1)

## Silence, on tourne...
fenetre1.AddRenderer(ren1)

## Definition de l'interacteur
iren1 = vtk.vtkRenderWindowInteractor()
iren1.SetRenderWindow(fenetre1)    # Set the rendering window being controlled by this object.

## Projection :
iren1.Initialize()  # Prepare for handling events. This must be called before the interactor will work.
fenetre1.Render()   
iren1.Start()       # Start the event loop. This is provided so that you do not have to implement your own event loop. You still can use your own event loop if you want. Initialize should be called before Start.

print '----------------------------------------------------'
