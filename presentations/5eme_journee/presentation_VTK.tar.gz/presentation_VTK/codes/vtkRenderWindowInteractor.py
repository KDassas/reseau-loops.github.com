#!/usr/bin/env python

import vtk
import time

print '----------------------------------------------------'

## Definition de la fenetre d'affichage
fenetre1 = vtk.vtkRenderWindow()
fenetre1.SetSize(500,500)
fenetre1.SetPosition(50,50) 
fenetre1.SetWindowName("Fenetre 1")

## Recuperation des donnees : ici une sphere
sphere1 = vtk.vtkSphereSource()
sphere1.SetRadius(1.0)             # Set radius of sphere. Default is .5.
sphere1.SetCenter(0.0,1.0,0.0)     # Set the center of the sphere. Default is 0,0,0.
sphere1.SetThetaResolution(20)      # Set the number of points in the longitude direction 
sphere1.SetPhiResolution(30)        # Set the number of points in the latitude direction

## Conversion des donnees en primitives graphiques 
mappersphere1 = vtk.vtkPolyDataMapper()
mappersphere1.SetInputConnection(sphere1.GetOutputPort())

## Definition des acteurs de la scene
acteursphere1 = vtk.vtkActor()
acteursphere1.SetMapper(mappersphere1)

## Definition de la scene : 
ren1 = vtk.vtkRenderer()
ren1.AddActor(acteursphere1)

## Silence, on tourne...
fenetre1.AddRenderer(ren1)

## Definition de l'interacteur
iren1 = vtk.vtkRenderWindowInteractor()
iren1.SetRenderWindow(fenetre1)    # Set the rendering window being controlled by this object.

## Projection :
iren1.Initialize()  # Prepare for handling events. This must be called before the interactor will work.
fenetre1.Render()   
iren1.Start()       # Start the event loop. This is provided so that you do not have to implement your own event loop. You still can use your own event loop if you want. Initialize should be called before Start.

print '----------------------------------------------------'
