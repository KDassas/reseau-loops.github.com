#include "vtkRenderWindow.h"
#include "vtkSphereSource.h"
#include "vtkPolyDataMapper.h"
#include "vtkActor.h"
#include "vtkRenderer.h"
#include "vtkRenderWindowInteractor.h"
using namespace std; 
int main (){
  vtkRenderWindow* fenetre =  vtkRenderWindow::New();
  vtkSphereSource* sphere =  vtkSphereSource::New();
  vtkPolyDataMapper* mappersphere =  vtkPolyDataMapper::New();
  mappersphere->SetInputConnection(sphere->GetOutputPort());
  vtkActor* acteursphere =  vtkActor::New();
  acteursphere->SetMapper(mappersphere);
  vtkRenderer* ren = vtkRenderer::New();
  ren->AddActor(acteursphere);
  fenetre->AddRenderer(ren);
  vtkRenderWindowInteractor* iren = vtkRenderWindowInteractor::New();
  iren->SetRenderWindow(fenetre);
  iren->Initialize();
  fenetre->Render();
  iren->Start(); 
  return 0;
}
