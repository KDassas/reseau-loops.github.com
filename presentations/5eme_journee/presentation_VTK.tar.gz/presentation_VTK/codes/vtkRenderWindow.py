#!/usr/bin/env python

import vtk
import time

print '----------------------------------------------------'
print 
print '----------------------------------------------------'

fenetre1 = vtk.vtkRenderWindow()
fenetre1.SetSize(300,300)
fenetre1.SetPosition(50,50)
fenetre1.SetWindowName("Fenetre 1")
print fenetre1

fenetre2 = vtk.vtkRenderWindow()
fenetre2.SetSize(300,300)
fenetre2.SetPosition(50+300+50,50)
fenetre2.SetWindowName("Fenetre 2")

fenetre1.Render()
fenetre2.Render()

time.sleep(10)

print '----------------------------------------------------'
