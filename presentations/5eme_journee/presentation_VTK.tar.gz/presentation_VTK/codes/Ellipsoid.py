#!/usr/bin/env python

import vtk
import time

print '----------------------------------------------------'

## Definition de la fenetre d'affichage
fenetre = vtk.vtkRenderWindow()
fenetre.SetSize(500,500)
fenetre.SetPosition(50,50) 
fenetre.SetWindowName("Fenetre")

## Recuperation des donnees : ici une sphere
sphere = vtk.vtkSphereSource()
sphere.SetThetaResolution(12)      # Set the number of points in the longitude direction 
sphere.SetPhiResolution(12)        # Set the number of points in the latitude direction

aTransform=vtk.vtkTransform()
aTransform.Scale(1,1.5,2)

transFilter=vtk.vtkTransformFilter()
transFilter.SetInputConnection(sphere.GetOutputPort())
transFilter.SetTransform(aTransform)

colorIt=vtk.vtkElevationFilter()
colorIt.SetInputConnection(transFilter.GetOutputPort())
colorIt.SetLowPoint(0,0,-1)
colorIt.SetHighPoint(0,0,1)


## Conversion des donnees en primitives graphiques 
mappersphere = vtk.vtkPolyDataMapper()
mappersphere.SetInputConnection(colorIt.GetOutputPort())

## Definition des acteurs de la scene
acteursphere = vtk.vtkActor()
acteursphere.SetMapper(mappersphere)

## Definition de la scene : 
ren = vtk.vtkRenderer()
ren.AddActor(acteursphere)

## Silence, on tourne...
fenetre.AddRenderer(ren)

## Definition de l'interacteur
iren = vtk.vtkRenderWindowInteractor()
iren.SetRenderWindow(fenetre)    # Set the rendering window being controlled by this object.

## Projection :
iren.Initialize()  # Prepare for handling events. This must be called before the interactor will work.
fenetre.Render()   
iren.Start()       # Start the event loop. This is provided so that you do not have to implement your own event loop. You still can use your own event loop if you want. Initialize should be called before Start.

print '----------------------------------------------------'
